package com.mobile.application.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="orders")

public class Orders {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	@Column(name="orderid")
	private int orderid;
	
	@Column(name="fullname")
	private String fullname;
	
	@Column(name="email")
	private String email;
	
	@Column(name="address")
	private String address;
	
	@Column(name="model")
	private int model;
	
	@Column(name="quantity")
	private int quantity;
	
	@Column(name="modeofpayment")
	private String modeofpayment;
	
	@Column(name="total")
	private int total;
	
	@Column(name="city")
	private String city;
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getModel() {
		return model;
	}

	public void setModel(int model) {
		this.model = model;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getModeofpayment() {
		return modeofpayment;
	}

	public void setModeofpayment(String modeofpayment) {
		this.modeofpayment = modeofpayment;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public Orders(String fullname, String email, String address, int model, int quantity, String modeofpayment,
			int total, String city) {
		super();
		this.fullname = fullname;
		this.email = email;
		this.address = address;
		this.model = model;
		this.quantity = quantity;
		this.modeofpayment = modeofpayment;
		this.total = total;
		this.city=city;
	}

	public Orders() {
		super();
	}

	@Override
	public String toString() {
		return "Orders [orderid=" + orderid + ", fullname=" + fullname + ", email=" + email + ", address=" + address
				+ ", model=" + model + ", quantity=" + quantity + ", modeofpayment=" + modeofpayment + ", total="
				+ total + ", city=" + city + "]";
	}
	
	
}
