package com.mobile.application.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mobile.application.model.Orders;


@Repository
public interface OrdersRepository extends CrudRepository<Orders, String> {

}
